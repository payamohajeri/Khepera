// Example for using position control with speed profile for Khepera 3


//  K-TEAM, J. Tharin, October 2011

//  cross-compilation: source the env.shfile, and make


#include <korebot/korebot.h>
#include <stdlib.h>
#include <stdio.h>

#define STEP 15 //cm
#define SPEED 20000

#define MAXBUFFERSIZE 100


#define Rot_left 0
#define Rot_right 1

#define PI 3.14159265358979
#define WHEEL_DISTANCE 88.41 //mm
#define MM_PER_PULSE 0.047

/*! handle to the various khepera3 devices (knet socket, i2c mode)
 */
static knet_dev_t * dsPic;
static knet_dev_t * mot1;
static knet_dev_t * mot2;

/*--------------------------------------------------------------------*/
/*! initMot initializes then configures the motor control
 * unit.
 *
 * \return A value :
 *      - 1 if success
 *      - 0 if any error
 *   
 */
int initMot(knet_dev_t *hDev)
{
  if(hDev)
  {
	  kmot_SetMode( hDev , kMotModeIdle );
	  kmot_SetSampleTime( hDev , 1550 );
	  kmot_SetMargin( hDev , 6 );
	  if(hDev == mot1)
	    kmot_SetOptions( hDev , 0x0 , kMotSWOptWindup | kMotSWOptStopMotorBlk | kMotSWOptDirectionInv);
	  else
	    kmot_SetOptions( hDev , 0x0 , kMotSWOptWindup | kMotSWOptStopMotorBlk );
	  kmot_ResetError( hDev );
	  kmot_SetBlockedTime( hDev , 10 );
	  kmot_SetLimits( hDev , kMotRegCurrent , 0 , 500 );
	  kmot_SetLimits( hDev , kMotRegPos , -10000 , 10000 );
	
	  /* PID  */
	  kmot_ConfigurePID( hDev , kMotRegSpeed , 620 , 3 , 10 ); // 400,0,10
	  kmot_ConfigurePID( hDev,kMotRegPos,600,20,30); // 620,3,10
	  kmot_SetSpeedProfile(hDev,15000,30); // previous 30,10

	  return 1;
  }
  else
  {
	  printf("initMot error, handle cannot be null\r\n");
	  return 0;
  }
}
													

/*--------------------------------------------------------------------*/
/*! initKH3 initialize various things in the kh3 then
 * sequentialy open the various required handle to the three i2c devices 
 * on the khepera3 using knet_open from the knet.c libkorebot's modules.
 * Finaly, this function initializes then configures the motor control
 * unit.
 *
 * \return A value :
 *      - 0 if success
 *      - <0 if any error
 */
int initKH3( void )
{
  /* This is required */
  kh3_init(); 
  
  /* open various socket and store the handle in their respective pointers */
  dsPic = knet_open( "Khepera3:dsPic" , KNET_BUS_I2C , 0 , NULL );
  mot1  = knet_open( "Khepera3:mot1" , KNET_BUS_I2C , 0 , NULL );
  mot2  = knet_open( "Khepera3:mot2" , KNET_BUS_I2C , 0 , NULL );

  if(dsPic!=0)
  {
    if((mot1!=0)&&(mot2!=0))
    {
      initMot(mot1);
      initMot(mot2);
      return 0;
    }
    else
      return -1;
  }

  return -2;

} 


/*--------------------------------------------------------------------*/
/*! configureOS configures various parameters inside the kh3 firmware
 *  using kb_khepera3.c library.
 *
 *  \param 1st first param (argv[1]) is the index pointing in configuration array.
 *  \param 2nd the second param (argv[2]) is the value to store where the index point at.
 *  
 */
int configureOS( int argc, char * argv[], void * data)
{
  char Buffer[MAXBUFFERSIZE];	/* buffer that handle the returned datas from kh3 */
  short index;			/* variable that handles index */
  short value;			/* variable that handle value */

  /* Retrive the arguments from the parameter */
  index = atoi(argv[1]);
  value = atoi(argv[2]);
  
  /* Configure */
  if(kh3_configure_os((char *)Buffer, index, value, dsPic))
  	printf("\r\n%c\r\n", Buffer[0]);
  else
	printf("\r\nc, error...\r\n");
}

/*--------------------------------------------------------------------*/
void move_forward()
{
    // calculate the motion time to move distance = STEP
    float t = STEP/(SPEED/1440.1); //in sec

		printf("t= %f\n",t);

    /* tell motor controllers to move K3 forward */
    kmot_SetPoint(mot1, kMotRegSpeed, SPEED);
    kmot_SetPoint(mot2, kMotRegSpeed, SPEED);
    usleep((int)(t*1000*1000));
    kmot_SetPoint( mot1, kMotRegSpeed, 0);
    kmot_SetPoint( mot2, kMotRegSpeed, 0);
}




/*--------------------------------------------------------------------*/
void move_forward_p(float pos_cm)
{

	float fpos;
	long lpos,rpos;
	
	// read old encoder position
	lpos = kmot_GetMeasure(mot1, kMotRegPos);
	rpos = kmot_GetMeasure(mot2, kMotRegPos);
	
	fpos = pos_cm*10.0/MM_PER_PULSE;  //  (1 pulse unit = 0.047mm)
  printf("moving forward cm = %.1f in pulses= %.1f\n",pos_cm,fpos);
  
  //printf("lpos= %ld  rpos= %ld\n",lpos, rpos);
  
    /* tell motor controllers to move K3 forward, using speed and accel profile */
  kmot_SetPoint(mot1, kMotRegPosProfile, lpos+(long)fpos);
  kmot_SetPoint(mot2, kMotRegPosProfile, rpos+(long)fpos);
  
  
  
}



/*--------------------------------------------------------------------*/
void rotate(int dir)
{
    // calculate the motion time to rotate 90 degrees around itself
    float realSpeed = SPEED/1440.1; // in mm/sec
    // distance between the wheels = 9 cm
    float t = (0.5*3.14159*9/2)/realSpeed; //in sec


		printf("t= %f\n",t);

    switch(dir){
    case Rot_left:
        kmot_SetPoint( mot1, kMotRegSpeed, -SPEED);
        kmot_SetPoint( mot2, kMotRegSpeed, SPEED);
  
  		printf("rotate left\n");
      break;

    case Rot_right:
        kmot_SetPoint( mot1, kMotRegSpeed, SPEED);
        kmot_SetPoint( mot2, kMotRegSpeed, -SPEED);
   			printf("rotate right\n");
        break;
    }
    usleep((int)(t*1000*1000));
    kmot_SetPoint( mot1, kMotRegSpeed, 0);
    kmot_SetPoint( mot2, kMotRegSpeed, 0);
}


/*--------------------------------------------------------------------*/
void rotate_p(float degree)
{

	float fpos;
	long lpos,rpos;
	
	lpos = kmot_GetMeasure(mot1, kMotRegPos);
	rpos = kmot_GetMeasure(mot2, kMotRegPos);
	
	fpos = degree/360.0*PI*WHEEL_DISTANCE/MM_PER_PULSE;  // from degree to mm to pulse 
  
  
  printf("rotating degree = %.1f in pulses= %.1f\n",degree,fpos);
  //printf("lpos= %ld  rpos= %ld\n",lpos, rpos);
  
  /* tell motor controllers to rotate K3, using speed and accel profile  */
  kmot_SetPoint(mot1, kMotRegPosProfile, lpos+(long)fpos);
  kmot_SetPoint(mot2, kMotRegPosProfile, rpos-(long)fpos);
  
  
}


/*--------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
	 int rc,i;
  char Buffer[MAXBUFFERSIZE];
  long lpos,rpos;

  // Set the libkorebot debug level - Highly recommended for development.
  kb_set_debug_level(2);

  // Init the korebot library 
  if((rc = kb_init( argc , argv )) < 0 )
    return 1;

	printf("Khepera3 motor test program (C) K-Team S.A\r\n");

  if(!initKH3())
  {
		printf("Init ok...\r\n");

		kh3_revision((char *)Buffer, dsPic);
		printf("\r\n%c,%4.4u,%4.4u => Version = %u, Revision = %u\r\n",
				   Buffer[0], (Buffer[1] | Buffer[2]<<8), (Buffer[3] | Buffer[4]<<8),  
				   (Buffer[1] | Buffer[2]<<8), (Buffer[3] | Buffer[4]<<8));
	
	
//	move_forward();
	
//	usleep(1500000); // wait 1.5s
	
	//move_forward_d(STEP);
//	rotate(1);
	
	
//	usleep(1500000); // wait 1.5s
	
	printf("\nMoving in a square shape of 15 cm of edge\n\n");
	
	for (i=0;i<4;i++) 
	{
		move_forward_p(15); // move 15 cm forward
	
		sleep(3); 
	
	
		/*lpos = kmot_GetMeasure(mot1, kMotRegPos);
		rpos = kmot_GetMeasure(mot2, kMotRegPos);
		printf("lpos= %ld  rpos= %ld\n",lpos, rpos);*/
	
	
		rotate_p(90); // rotate 90deg (right)
	
		sleep(3); 
	
		/*lpos = kmot_GetMeasure(mot1, kMotRegPos);
		rpos = kmot_GetMeasure(mot2, kMotRegPos);
		printf("lpos= %ld  rpos= %ld\n",lpos, rpos);*/
	}
	
	printf("\nEnd\n");
	
	}	
 return 0;
 
}

